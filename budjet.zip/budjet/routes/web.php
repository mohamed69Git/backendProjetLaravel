<?php

use App\Models\CategorieDepense;
use App\Http\Controllers\CategorieDepenseController;
use App\Http\Controllers\CategorieRevenuController;
use App\Http\Controllers\DepenseCommunController;
use App\Http\Controllers\DepenseFixeController;
use App\Http\Controllers\DepenseFixeFrequenceVariableController;
use App\Http\Controllers\DepenseSpontaneeController;
use App\Http\Controllers\RevenuController;
use App\Models\CategorieRevenu;
use App\Models\DepenseFixeFrequenceVariable;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::resource('revenus', RevenuController::class);
Route::resource('categorierevenus', CategorieRevenuController::class);
Route::resource('depensecommuns', DepenseCommunController::class);
Route::resource('categoriedepenses',CategorieDepenseController::class);

Route::get('/', function(){return view('welcome');});
