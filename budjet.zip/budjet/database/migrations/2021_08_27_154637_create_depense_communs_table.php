<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDepenseCommunsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('depense_communs', function (Blueprint $table) {
            $table->id();
            $table->double('montantDepense')->require()->unsigned();
            $table->text('description')->require();

            $table->bigInteger('id_categorie_depense')->require();
            $table->foreign('id_categorie_depense')->references('id')->on('categorie_depenses')->onDelete('cascade')->onUpdate('cascade')->require();

            $table->bigInteger('id_depense_fixe')->nullable();
            $table->foreign('id_depense_fixe')->references('id')->on('depense_fixes')->onUpdate('cascade')->onDelete('cascade');

            $table->bigInteger('id_depense_spontanees')->nullable();
            $table->foreign('id_depense_spontanees')->references('id')->on('depense_spontanees')->onUpdate('cascade')->onDelete('cascade');

            $table->bigInteger('id_depense_fixe_frequence_variables')->nullable();
            $table->foreign('id_depense_fixe_frequence_variables')->references('id')->on('depense_fixe_frequence_variables')->onUpdate('cascade')->onDelete('cascade');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('depense_communs');
    }
}
