<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DepenseCommun extends Model
{
    use HasFactory;
    protected $fillable = [
        'montantDepense',
        'description',
        'id_categorie_depense',
        'id_depense_fixe',
        'id_depense_spontanees',
        'id_depense_fixe_frequence_variables'
    ];
}
