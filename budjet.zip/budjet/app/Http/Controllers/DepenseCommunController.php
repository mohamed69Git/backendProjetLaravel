<?php

namespace App\Http\Controllers;

use App\Models\CategorieDepense;
use App\Models\DepenseCommun;
use App\Models\DepenseFixe;
use App\Models\DepenseFixeFrequenceVariable;
use App\Models\DepenseSpontanee;
use App\Models\Revenu;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DepenseCommunController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = DB::table('depense_communs')
            ->join('depense_spontanees', 'depense_spontanees.id', '=', 'id_depense_spontanees')
            ->join('categorie_depenses', 'categorie_depenses.id', '=', 'id_categorie_depense')
            ->select('categorie_depenses.nomCategorie as depenseCat', 'depense_spontanees.nomCategorie as categorieName', 'montantDepense', 'description', 'depense_communs.id as mainId')
            ->get();

        $data = $data->merge(DB::table('depense_communs')
            ->join('depense_fixes', 'depense_fixes.id', '=', 'id_depense_fixe')
            ->join('categorie_depenses', 'categorie_depenses.id', '=', 'id_categorie_depense')
            ->select('categorie_depenses.nomCategorie as depenseCat', 'depense_fixes.nomCategorie as categorieName', 'montantDepense', 'description', 'depense_communs.id as mainId')
            ->get());

        $data = $data->merge(
            DB::table('depense_communs')
                ->join('depense_fixe_frequence_variables', 'depense_fixe_frequence_variables.id', '=', 'id_depense_fixe_frequence_variables')
                ->join('categorie_depenses', 'categorie_depenses.id', '=', 'id_categorie_depense')
                ->select('categorie_depenses.nomCategorie as depenseCat', 'depense_fixe_frequence_variables.nomCategorie as categorieName', 'montantDepense', 'description', 'depense_communs.id as mainId')
                ->get()
        );
        $depensetotal = DepenseCommun::all();
        $revenutotal = Revenu::all();
        $revenu=0;
        foreach ($revenutotal as $item) {
            $revenu+=$item->montantRevenu;
        }
        $depense = 0;
        foreach ($depensetotal as $item) {
            $depense += $item->montantDepense;
        }
        return view('depensecommuns.index', compact('data', 'depense', 'revenu'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $datadepense = CategorieDepense::all();
        $datafixe = DepenseFixe::all();
        $dataspont = DepenseSpontanee::all();
        $datafixevar = DepenseFixeFrequenceVariable::all();
        $total = [$datafixe, $dataspont, $datafixevar];
        $i = 0;
        return view('depensecommuns.create', compact('datadepense', 'total', 'i'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $datafixevar = DepenseFixeFrequenceVariable::all();
        $datafixe = DepenseFixe::all();
        $dataspont = DepenseSpontanee::all();
        $total = [$datafixe, $dataspont, $datafixevar];
        $i = 0;
        $idrecherche = 0;
        $idCate = 0;
        //verifier l'appartenance du type de categorie choisi dans le formulaire
        while ($i < count($total)) {
            foreach ($total[$i] as $item) {
                if ($item->nomCategorie == $request->theId) {
                    $idCate = $i + 1;
                    $idrecherche = $item->id;
                    break;
                }
            }
            $i++;
        }
        $depensetotal = DepenseCommun::all();
        $revenutotal = Revenu::all();
        $revenu=0;
        foreach ($revenutotal as $item) {
            $revenu+=$item->montantRevenu;
        }
        $depense = 0;
        foreach ($depensetotal as $item) {
            $depense += $item->montantDepense;
        }
        if ($idCate == 1 && $revenu-$depense>$request->montant) {
            DepenseCommun::create([
                'montantDepense' => $request->montant,
                'description' => $request->description,
                'id_categorie_depense' => $idCate,
                'id_depense_fixe' => $idrecherche,
            ]);
        }
        elseif ($idCate == 2 && $revenu-$depense>$request->montant) {
            DepenseCommun::create([
                'montantDepense' => $request->montant,
                'description' => $request->description,
                'id_categorie_depense' => $idCate,
                'id_depense_fixe',
                'id_depense_spontanees' => $idrecherche,
                'id_depense_fixe_frequence_variables'
            ]);
        }
        elseif($idCate==3 && $revenu-$depense>$request->montant){
            DepenseCommun::create([
                'montantDepense' => $request->montant,
                'description' => $request->description,
                'id_categorie_depense' => $idCate,
                'id_depense_fixe',
                'id_depense_spontanees',
                'id_depense_fixe_frequence_variables' => $idrecherche
            ]);
        }
        else
            return redirect()->route('depensecommuns.create')->with('echec', 'Impossible, votre solde restant est inferieur');
        return redirect()->route('depensecommuns.create');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\DepenseCommun  $depensecommun
     * @return \Illuminate\Http\Response
     */
    public function show(DepenseCommun $depensecommun)
    {
        $categorie = DB::table('categorie_depenses')
            ->where('id', '=', $depensecommun->id_categorie_depense)
            ->get();


        $data = DB::table('depense_fixes')

            ->join('depense_communs', 'depense_communs.id_depense_fixe', '=', 'depense_fixes.id')
            ->where('depense_fixes.id', '=', $depensecommun->id_depense_fixe)
            // ->join('categorie_depenses', 'categorie_depenses.id', '=', 'id_categorie_depense')
            // ->select('categorie_depenses.nomCategorie as depenseCat', 'depense_spontanees.nomCategorie as categorieName', 'montantDepense', 'description', 'depense_communs.id as mainId')
            ->first();

        $data2 = DB::table('depense_spontanees')

            ->join('depense_communs', 'depense_communs.id_depense_spontanees', '=', 'depense_spontanees.id')
            ->where('depense_spontanees.id', '=', $depensecommun->id_depense_spontanees)
            ->first();
        // ->join('categorie_depenses', 'categorie_depenses.id', '=', 'id_categorie_depense')
        // ->select('categorie_depenses.nomCategorie as depenseCat', 'depense_spontanees.nomCategorie as categorieName', 'montantDepense', 'description', 'depense_communs.id as mainId')

        $data3 = DB::table('depense_fixe_frequence_variables')

            ->join('depense_communs', 'depense_communs.id_depense_fixe_frequence_variables', '=', 'depense_fixe_frequence_variables.id')
            ->where('depense_fixe_frequence_variables.id', '=', $depensecommun->id_depense_fixe_frequence_variables)
            // ->join('categorie_depenses', 'categorie_depenses.id', '=', 'id_categorie_depense')
            // ->select('categorie_depenses.nomCategorie as depenseCat', 'depense_spontanees.nomCategorie as categorieName', 'montantDepense', 'description', 'depense_communs.id as mainId')
            ->first();
        $datafin = "";
        if ($data) {
            $datafin = $data;
            return view('depensecommuns.show', compact('depensecommun', 'datafin', 'categorie'));
        } elseif ($data2) {
            $datafin = $data2;
            return view('depensecommuns.show', compact('depensecommun', 'datafin', 'categorie'));
        } else {
            $datafin = $data3;
            return view('depensecommuns.show', compact('depensecommun', 'datafin', 'categorie'));
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\DepenseCommun  $depensecommun
     * @return \Illuminate\Http\Response
     */
    public function edit(DepenseCommun $depensecommun)
    {
        $datadepense = CategorieDepense::all();
        $datafixe = DepenseFixe::all();
        $dataspont = DepenseSpontanee::all();
        $datafixevar = DepenseFixeFrequenceVariable::all();
        $total = [$datafixe, $dataspont, $datafixevar];
        $i = 0;
        return view('depensecommuns.edit', compact('datadepense', 'total', 'i', 'depensecommun'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\DepenseCommun  $depensecommun
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DepenseCommun $depensecommun)
    {
        $datafixevar = DepenseFixeFrequenceVariable::all();
        $datafixe = DepenseFixe::all();
        $dataspont = DepenseSpontanee::all();
        $total = [$datafixe, $dataspont, $datafixevar];
        $i = 0;
        $idrecherche = 0;
        $idCate = 0;
        //verifier l'appartenance du type de categorie choisi dans le formulaire
        while ($i < count($total)) {
            foreach ($total[$i] as $item) {
                if ($item->nomCategorie == $request->theId) {
                    $idCate = $i + 1;
                    $idrecherche = $item->id;
                    break;
                }
            }
            $i++;
        }
        if ($idCate == 1) {
            $depensecommun->update([
                'montantDepense' => $request->montant,
                'description' => $request->description,
                'id_categorie_depense' => $idCate,
                'id_depense_fixe' => $idrecherche,
            ]);
        } else if ($idCate == 2) {
            $depensecommun->update([
                'montantDepense' => $request->montant,
                'description' => $request->description,
                'id_categorie_depense' => $idCate,
                'id_depense_fixe',
                'id_depense_spontanees' => $idrecherche,
                'id_depense_fixe_frequence_variables'
            ]);
        } else {
            $depensecommun->update([
                'montantDepense' => $request->montant,
                'description' => $request->description,
                'id_categorie_depense' => $idCate,
                'id_depense_fixe',
                'id_depense_spontanees',
                'id_depense_fixe_frequence_variables' => $idrecherche
            ]);
        }
        return redirect()->route('depensecommuns.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\DepenseCommun  $depensecommun
     * @return \Illuminate\Http\Response
     */
    public function destroy(DepenseCommun $depensecommun)
    {
        $depensecommun->delete();
        return redirect()->route('depensecommuns.index');
    }


    public function addDepenseCom()
    {
        $soldeRestant = 0;
        $revenu = Revenu::all();
        foreach ($revenu as $i) {
            $soldeRestant += $i->montantRevenu;
        }

        $depenses = DepenseCommun::all();
        $totalDepense = 0;
        foreach ($depenses as $depense) {
            $totalDepense += $depense->montantDepense;
        }
        $soldeRestant = $soldeRestant - $totalDepense;
        $montant = 2000;
        if ($soldeRestant > $montant) {
            DepenseCommun::create([
                'montantDepense' => $montant,
                'id_categorie_depense' => 3,
                'description' => 'paiment a seneau',
                'id_depense_fixe',
                'id_depense_spontanees',
                'id_depense_fixe_frequence_variables' => 1
            ]);
        }
    }
}
