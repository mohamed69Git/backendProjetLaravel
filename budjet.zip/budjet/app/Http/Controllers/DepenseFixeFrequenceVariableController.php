<?php

namespace App\Http\Controllers;

use App\Models\DepenseFixeFrequenceVariable;
use Illuminate\Http\Request;

class DepenseFixeFrequenceVariableController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\DepenseFixeFrequenceVariable  $depenseFixeFrequenceVariable
     * @return \Illuminate\Http\Response
     */
    public function show(DepenseFixeFrequenceVariable $depenseFixeFrequenceVariable)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\DepenseFixeFrequenceVariable  $depenseFixeFrequenceVariable
     * @return \Illuminate\Http\Response
     */
    public function edit(DepenseFixeFrequenceVariable $depenseFixeFrequenceVariable)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\DepenseFixeFrequenceVariable  $depenseFixeFrequenceVariable
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DepenseFixeFrequenceVariable $depenseFixeFrequenceVariable)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\DepenseFixeFrequenceVariable  $depenseFixeFrequenceVariable
     * @return \Illuminate\Http\Response
     */
    public function destroy(DepenseFixeFrequenceVariable $depenseFixeFrequenceVariable)
    {
        //
    }

    public function addDepfixVar()
    {
        DepenseFixeFrequenceVariable::create([
            'nomCategorie'=>'facture d\'eau'
        ]);
    }
}
