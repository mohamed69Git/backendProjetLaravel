<?php

namespace App\Http\Controllers;

use App\Models\DepenseSpontanee;
use Illuminate\Http\Request;

class DepenseSpontaneeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\DepenseSpontanee  $depenseSpontanee
     * @return \Illuminate\Http\Response
     */
    public function show(DepenseSpontanee $depenseSpontanee)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\DepenseSpontanee  $depenseSpontanee
     * @return \Illuminate\Http\Response
     */
    public function edit(DepenseSpontanee $depenseSpontanee)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\DepenseSpontanee  $depenseSpontanee
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DepenseSpontanee $depenseSpontanee)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\DepenseSpontanee  $depenseSpontanee
     * @return \Illuminate\Http\Response
     */
    public function destroy(DepenseSpontanee $depenseSpontanee)
    {
        //
    }

    public function addDepSpont()
    {
        DepenseSpontanee::create([
            'nomCategorie'=>'médicaments'
        ]);
    }
}
