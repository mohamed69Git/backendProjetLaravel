<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use App\Models\CategorieRevenu;
use App\Models\Revenu;
use Illuminate\Http\Request;

class RevenuController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $revenus = DB::table('categorie_revenus')
        ->join('revenus', 'revenus.id_categorie_revenus', 'categorie_revenus.id')
        ->select('nomcategorie', 'montantRevenu', 'revenus.created_at as datecrea', 'revenus.id as mainId')
        ->get();
        return view('revenus.index', compact('revenus'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = CategorieRevenu::all();
        return view('revenus.create', compact('data'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        Revenu::create([
            'montantRevenu'=>$request->montantrevenu,
            'id_categorie_revenus'=>$request->caterevenu
        ]);
        return redirect()->route('revenus.create');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Revenu  $revenu
     * @return \Illuminate\Http\Response
     */
    public function show(Revenu $revenu)
    {
        $categorie = DB::table('categorie_revenus')
        ->where('categorie_revenus.id', '=', $revenu->id_categorie_revenus)
        ->get();

        return view('revenus.show', compact('revenu', 'categorie'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Revenu  $revenu
     * @return \Illuminate\Http\Response
     */
    public function edit(Revenu $revenu)
    {
        $data = CategorieRevenu::all();
        return view('revenus.edit', compact('revenu', 'data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Revenu  $revenu
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Revenu $revenu)
    {
        $revenu->update([
            'montantRevenu'=>$request->montantrevenu,
            'id_categorie_revenus'=>$request->caterevenu
        ]);
        return redirect()->route('revenus.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Revenu  $revenu
     * @return \Illuminate\Http\Response
     */
    public function destroy(Revenu $revenu)
    {
        $revenu->delete();
        return redirect()->route('revenus.index');
    }


}
