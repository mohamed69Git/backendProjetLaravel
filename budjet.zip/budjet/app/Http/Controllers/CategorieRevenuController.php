<?php

namespace App\Http\Controllers;

use App\Models\CategorieRevenu;
use Illuminate\Http\Request;

class CategorieRevenuController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('categorierevenus.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        CategorieRevenu::create([
            'nomcategorie'=>$request->categ
        ]);
        return redirect()->route('categoriedepenses.create');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\CategorieRevenu  $categorieRevenu
     * @return \Illuminate\Http\Response
     */
    public function show(CategorieRevenu $categorieRevenu)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\CategorieRevenu  $categorieRevenu
     * @return \Illuminate\Http\Response
     */
    public function edit(CategorieRevenu $categorieRevenu)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\CategorieRevenu  $categorieRevenu
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CategorieRevenu $categorieRevenu)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\CategorieRevenu  $categorieRevenu
     * @return \Illuminate\Http\Response
     */
    public function destroy(CategorieRevenu $categorieRevenu)
    {
        //
    }

    public function addCategorie(){
        CategorieRevenu::create([
            'nomcategorie'=>'salaire'
        ]);
    }
}
