<?php

namespace App\Http\Controllers;

use App\Models\CategorieDepense;
use App\Models\DepenseFixe;
use App\Models\DepenseFixeFrequenceVariable;
use App\Models\DepenseSpontanee;
use Illuminate\Http\Request;

class CategorieDepenseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('categoriedepenses.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // dd($request->sousCat, $request->categParent);
        if ($request->categParent == 1)
            DepenseFixe::create([
                'nomCategorie' => $request->sousCat
            ]);
        elseif ($request->categParent == 3)
            DepenseSpontanee::create([
                'nomCategorie' => $request->sousCat
            ]);
        else
            DepenseFixeFrequenceVariable::create([
                'nomCategorie'=> $request->sousCat
            ]);
        return redirect()->route('categoriedepenses.create');

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\CategorieDepense  $categorieDepense
     * @return \Illuminate\Http\Response
     */
    public function show(CategorieDepense $categorieDepense)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\CategorieDepense  $categorieDepense
     * @return \Illuminate\Http\Response
     */
    public function edit(CategorieDepense $categorieDepense)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\CategorieDepense  $categorieDepense
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CategorieDepense $categorieDepense)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\CategorieDepense  $categorieDepense
     * @return \Illuminate\Http\Response
     */
    public function destroy(CategorieDepense $categorieDepense)
    {
        //
    }

    public function addCategorie()
    {

        CategorieDepense::create([
            'nomCategorie' => 'depense fixe frequence variable',
        ]);
        return view('welcome');
    }
}
