<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/css/bootstrap.css">
    <link rel="stylesheet" href="/css/all.css">
  </head>
  <body>
    <table class="table table-hover table-inverse table-responsive">
        <thead class="thead-inverse">
            <tr>
                <th>Description</th>
                <th>Montant de la depense</th>
                <th>Categorie de la depense</th>
                <th>type</th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $depenseCommun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td scope="row"><?php echo e($depenseCommun->description); ?></td>
                    <td><?php echo e($depenseCommun->montantDepense); ?></td>
                    <td><?php echo e($depenseCommun->depenseCat); ?></td>
                    <td><?php echo e($depenseCommun->categorieName); ?></td>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </tbody>
    </table>
    <div class="card text-left mt-5">
      <div class="card-body">
        <h4 class="card-title">Depense total</h4>
        <p class="card-text"><?php echo e($depense); ?></p>
      </div>
    </div>
    <div class="card text-left mt-5">
        <div class="card-body">
            <button class="btn btn-primary">ajouter une depense</button>
        </div>
      </div>

  </body>
</html>
<?php /**PATH /home/ahmad/budjet/resources/views/depense/index.blade.php ENDPATH**/ ?>