<?php $__env->startSection('content'); ?>
<form action=<?php echo e(route('depensecommuns.update', $depensecommun)); ?> method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="form-group">
        <label for="">Montant</label>
        <input type="number" step="0.01" value="<?php echo e($depensecommun->montantDepense); ?>" name="montant" id="" class="form-control" placeholder=""
            aria-describedby="helpId">
    </div>
    <div class="form-group">
        <label for="">Description dépense</label>
        <input type="text" class="form-control" value="<?php echo e($depensecommun->description); ?>" name="description" id="" aria-describedby="helpId" placeholder="">
    </div>
    <div class="form-group">
        <label for="">Categorie de la dépense</label>
        <select class="form-control" name="theId" id="">
            <?php $__currentLoopData = $datadepense; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <optgroup label="<?php echo e($myitem->nomCategorie); ?>">
                    <?php $__currentLoopData = $total[$i]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemtotal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($itemtotal->nomCategorie); ?>">
                            <?php echo e($itemtotal->nomCategorie); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($i+=1); ?>


                </optgroup>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <button type="submit" class="btn btn-primary float-right">Submit</button>
    <a href="<?php echo e(route('depensecommuns.index')); ?>" class="btn btn-primary">annuler</a>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ahmad/budjet/resources/views/depensecommuns/edit.blade.php ENDPATH**/ ?>