<?php $__env->startSection('content'); ?>
    <div class="card">
        <h4 class="text-center">Depense</h4>
        <div class="card-body">
            <table class="table">
                <tbody>
                    <tr>
                        <td scope="row"><strong>description:   </strong> <?php echo e($depensecommun->description); ?></td>

                    </tr>
                    <tr>
                        <td scope="row"><strong>montant:   </strong> <?php echo e($depensecommun->montantDepense); ?></td>
                    </tr>
                    <tr scope="row">
                        <?php $__currentLoopData = $categorie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catego): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td><strong>categorie:  </strong> <?php echo e($catego->nomCategorie); ?></td>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <tr>
                        <td scope="row"><strong>Sous categorie: </strong> <?php echo e($datafin->nomCategorie); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <a class="btn btn-primary float-right mt-5" href="<?php echo e(route('depensecommun.index')); ?>">retour</a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ahmad/budjet/resources/views/depensecommun/show.blade.php ENDPATH**/ ?>