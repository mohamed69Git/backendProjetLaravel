<?php $__env->startSection('content'); ?>
    <table class="table table-hover table-inverse table-responsive">
        <thead class="thead-inverse">
            <tr>
                <th>Description</th>
                <th>Montant de la depense</th>
                <th>Categorie de la depense</th>
                <th>type</th>
                <td>options</td>

            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $depensecommun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td scope="row"><?php echo e($depensecommun->description); ?></td>
                    <td><?php echo e($depensecommun->montantDepense); ?></td>
                    <td><?php echo e($depensecommun->depenseCat); ?></td>
                    <td><?php echo e($depensecommun->categorieName); ?></td>
                    <td>
                        <a title="afficher" href="<?php echo e(route('depensecommuns.show', $depensecommun->mainId)); ?>"
                            role="button"><i class="fa fa-eye" aria-hidden="true"></i></a>
                        <a title="modifier" href="<?php echo e(route('depensecommuns.edit', $depensecommun->mainId)); ?>"
                            role="button" class="ml-3"><i class="fas fa-pen"></i></a>
                        <form action="<?php echo e(route('depensecommuns.destroy', $depensecommun->mainId)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button title="supprimer" class="btn btn-primary" type="submit"><i class="fa fa-trash"
                                    aria-hidden="true"></i></button>
                        </form>
                    </td>
                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="card">
        <div class="card-body">
            <table class="table  table-inverse table-responsive">

                <tbody>
                    <tr>
                        <td scope="row"><strong>Revenu: </strong><?php echo e($revenu); ?>FCFA </td>
                    </tr>
                    <tr>

                        <td><strong>Depense total: </strong> <?php echo e($depense); ?>FCFA</span></td>
                    </tr>
                    <tr>

                        <td><strong>Solde actuel: </strong><?php echo e($revenu-$depense); ?>FCFA</td>
                    </tr>


                </tbody>
            </table>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ahmad/budjet/resources/views/depensecommuns/index.blade.php ENDPATH**/ ?>