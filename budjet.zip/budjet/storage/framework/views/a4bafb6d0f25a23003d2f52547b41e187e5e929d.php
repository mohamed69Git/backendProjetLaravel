<!doctype html>
<html lang="en">

<head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/css/fontawesome-free-5.15.4-web/css/all.css">
    <link rel="stylesheet" href="/css/bootstrap.min.css">
</head>

<body>
    <nav class="navbar navbar-expand-sm navbar-light bg-light">
        <a class="navbar-brand" href="#">Navbar</a>
        <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId"
            aria-controls="collapsibleNavId" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapsibleNavId">
            <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                <li class="nav-item active">
                    <a class="nav-link" href="/">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('depensecommuns.index')); ?>">voir les depenses</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link strong" href="<?php echo e(route('revenus.index')); ?>">voir les revenus</a>
                </li>
                <li class="nav-item">
                    <a href=<?php echo e(route('depensecommuns.create')); ?> class="nav-link">ajouter une depense</a>
                </li>
                <li class="nav-item">
                    <a href=<?php echo e(route('revenus.create')); ?> class="nav-link">ajouter un revenu</a>
                </li>


            </ul>

        </div>
    </nav>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="/js/jquery-3.3.1.slim.min.js"></script>
    <script src="/js/popper.min.js"></script>
    <script src="/js/bootstrap.min.js"></script>
</body>

</html>
<?php /**PATH /home/ahmad/budjet/resources/views/master.blade.php ENDPATH**/ ?>