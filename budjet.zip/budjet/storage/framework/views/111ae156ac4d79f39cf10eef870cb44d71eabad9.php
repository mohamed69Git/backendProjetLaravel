<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('categoriedepenses.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('POST'); ?>
    <div class="form-group">
      <label for="">nom de la sous categorie</label>
      <input type="text" name="sousCat" id="" class="form-control" placeholder="" aria-describedby="helpId">
    </div>

    <div class="form-group">
      <label for="">Categorie </label>
      <select class="form-control" name="categParent" id="">
        <option value=1>Dépense Fixe</option>
        <option value=2>Dépense Fixe Frequence Variable</option>
        <option value=3>Dépense Spontanées</option>
      </select>
    </div>
    <button type="submit" class="btn btn-primary float-right">Submit</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ahmad/budjet/resources/views/categoriedepenses/create.blade.php ENDPATH**/ ?>