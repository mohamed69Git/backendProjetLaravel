<?php $__env->startSection('content'); ?>
    <table class="table table-striped table-inverse table-responsive">
        <thead class="thead-inverse">
            <tr>
                <th>revenu</th>
                <th>categorie</th>
                <th>Date de creation</th>
                <td></td>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $revenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td scope="row"><?php echo e($revenu->montantRevenu); ?></td>
                    <td><?php echo e($revenu->nomcategorie); ?></td>
                    <td><?php echo e($revenu->datecrea); ?></td>
                    <td>
                        <a title="afficher" href="<?php echo e(route('revenus.show', $revenu->mainId)); ?>" class="btn btn-primary"
                            role="button"><i class="fa fa-eye" aria-hidden="true"></i></a>
                        <a title="modifier" href="<?php echo e(route('revenus.edit', $revenu->mainId)); ?>" role="button"
                            class="ml-3 btn btn-primary"><i class="fas fa-pen"></i></a>
                        <form action="<?php echo e(route('revenus.destroy', $revenu->mainId)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button title="supprimer" class="btn btn-primary" type="submit"><i class="fa fa-trash"
                                    aria-hidden="true"></i></button>
                        </form>
                    </td>
                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ahmad/budjet/resources/views/revenus/index.blade.php ENDPATH**/ ?>