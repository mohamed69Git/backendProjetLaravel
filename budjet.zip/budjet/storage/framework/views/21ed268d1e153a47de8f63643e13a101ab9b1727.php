<?php $__env->startSection('content'); ?>
<h1>page <i class="fas fa-edit    "></i></h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ahmad/budjet/resources/views/depensecommun/edit.blade.php ENDPATH**/ ?>