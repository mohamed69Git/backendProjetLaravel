<?php $__env->startSection('content'); ?>
    <div class="card">
        <h4 class="text-center">Revenu</h4>
        <div class="card-body">
            <table class="table">
                <tbody>
                    <tr>
                        <td scope="row"><strong>Revenu: </strong> <?php echo e($revenu->montantRevenu); ?></td>

                    </tr>
                    <tr>
                        <?php $__currentLoopData = $categorie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <td scope="row"><strong>categorie: </strong> <?php echo e($categorie->nomcategorie); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <tr scope="row">
                        <td><strong>date de creation: </strong> <?php echo e($revenu->created_at); ?></td>

                    </tr>

                </tbody>
            </table>
        </div>
    </div>
    <a class="btn btn-primary float-right mt-5" href="<?php echo e(route('revenus.index')); ?>">retour</a>
    <a class="btn btn-primary float-right mt-5" href="<?php echo e(route('depensecommuns.index')); ?>">voir les depenses</a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ahmad/budjet/resources/views/revenus/show.blade.php ENDPATH**/ ?>