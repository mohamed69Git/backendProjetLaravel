<?php $__env->startSection('content'); ?>
<form action="" method="post">
    <div class="form-group">
      <label for="">nom de la sous categorie</label>
      <input type="text" name="sousCat" id="" class="form-control" placeholder="" aria-describedby="helpId">
    </div>

    <div class="form-group">
      <label for="">Categorie </label>
      <select class="form-control" name="categParent" id="">
        <option value="">Dépense Fixe</option>
        <option value="">Dépense Fixe Frequence Variable</option>
        <option value="">Dépense Spontanées</option>
      </select>
    </div>
    <button type="submit" class="btn btn-primary float-right">Submit</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ahmad/budjet/resources/views/categoriedepense/create.blade.php ENDPATH**/ ?>