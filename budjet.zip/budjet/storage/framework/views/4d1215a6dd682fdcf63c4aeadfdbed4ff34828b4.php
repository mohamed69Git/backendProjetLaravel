<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('categorierevenus.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('POST'); ?>
    <div class="form-group">
      <label for="">Nom de la catégorie</label>
      <input type="text" required name="categ" id="" class="form-control" placeholder="" aria-describedby="helpId">
    </div>
    <button type="submit" class="btn btn-primary float-right">Submit</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ahmad/budjet/resources/views/categorierevenus/create.blade.php ENDPATH**/ ?>