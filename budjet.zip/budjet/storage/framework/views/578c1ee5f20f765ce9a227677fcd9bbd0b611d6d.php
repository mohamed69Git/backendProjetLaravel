<?php $__env->startSection('content'); ?>
    <form action=<?php echo e(route('depensecommun.store')); ?> method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>
        <div class="form-group">
            <label for="">Montant</label>
            <input type="number" step="0.01" name="montant" id="" class="form-control" placeholder=""
                aria-describedby="helpId">
        </div>
        <div class="form-group">
            <label for="">Description dépense</label>
            <input type="text" class="form-control" name="description" id="" aria-describedby="helpId" placeholder="">
        </div>
        <div class="form-group">
            <label for="">Categorie de la dépense</label>
            <select class="form-control" name="theId" id="">
                <?php $__currentLoopData = $datadepense; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <optgroup label="<?php echo e($myitem->nomCategorie); ?>">
                        <?php $__currentLoopData = $total[$i]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemtotal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($itemtotal->nomCategorie); ?>">
                                <?php echo e($itemtotal->nomCategorie); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($i+=1); ?>


                    </optgroup>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary float-right">Submit</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ahmad/budjet/resources/views/depensecommun/create.blade.php ENDPATH**/ ?>