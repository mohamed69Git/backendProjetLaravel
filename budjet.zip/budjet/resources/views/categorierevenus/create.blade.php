@extends('master')
@section('content')
<form action="{{route('categorierevenus.store')}}" method="post">
    @csrf
    @method('POST')
    <div class="form-group">
      <label for="">Nom de la catégorie</label>
      <input type="text" required name="categ" id="" class="form-control" placeholder="" aria-describedby="helpId">
    </div>
    <button type="submit" class="btn btn-primary float-right">Submit</button>
</form>
@endsection
