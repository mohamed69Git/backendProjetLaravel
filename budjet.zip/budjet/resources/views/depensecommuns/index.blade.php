@extends('master')
@section('content')
    <table class="table table-hover table-inverse table-responsive">
        <thead class="thead-inverse">
            <tr>
                <th>Description</th>
                <th>Montant de la depense</th>
                <th>Categorie de la depense</th>
                <th>type</th>
                <td>options</td>

            </tr>
        </thead>
        <tbody>
            @foreach ($data as $depensecommun)

                <tr>
                    <td scope="row">{{ $depensecommun->description }}</td>
                    <td>{{ $depensecommun->montantDepense }}</td>
                    <td>{{ $depensecommun->depenseCat }}</td>
                    <td>{{ $depensecommun->categorieName }}</td>
                    <td>
                        <a title="afficher" href="{{ route('depensecommuns.show', $depensecommun->mainId) }}"
                            role="button"><i class="fa fa-eye" aria-hidden="true"></i></a>
                        <a title="modifier" href="{{ route('depensecommuns.edit', $depensecommun->mainId) }}"
                            role="button" class="ml-3"><i class="fas fa-pen"></i></a>
                        <form action="{{ route('depensecommuns.destroy', $depensecommun->mainId) }}" method="post">
                            @csrf
                            @method('DELETE')
                            <button title="supprimer" class="btn btn-primary" type="submit"><i class="fa fa-trash"
                                    aria-hidden="true"></i></button>
                        </form>
                    </td>
                </tr>

            @endforeach
        </tbody>
    </table>
    <div class="card">
        <div class="card-body">
            <table class="table  table-inverse table-responsive">

                <tbody>
                    <tr>
                        <td scope="row"><strong>Revenu: </strong>{{$revenu}}FCFA </td>
                    </tr>
                    <tr>

                        <td><strong>Depense total: </strong> {{ $depense }}FCFA</span></td>
                    </tr>
                    <tr>

                        <td><strong>Solde actuel: </strong>{{$revenu-$depense}}FCFA</td>
                    </tr>


                </tbody>
            </table>
        </div>
    </div>



@endsection
