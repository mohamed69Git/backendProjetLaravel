@extends('master')
@section('content')
<form action={{ route('depensecommuns.update', $depensecommun) }} method="post">
    @csrf
    @method('PUT')
    <div class="form-group">
        <label for="">Montant</label>
        <input type="number" step="0.01" value="{{$depensecommun->montantDepense}}" name="montant" id="" class="form-control" placeholder=""
            aria-describedby="helpId">
    </div>
    <div class="form-group">
        <label for="">Description dépense</label>
        <input type="text" class="form-control" value="{{$depensecommun->description}}" name="description" id="" aria-describedby="helpId" placeholder="">
    </div>
    <div class="form-group">
        <label for="">Categorie de la dépense</label>
        <select class="form-control" name="theId" id="">
            @foreach ($datadepense as $myitem)
                <optgroup label="{{ $myitem->nomCategorie }}">
                    @foreach ($total[$i] as $itemtotal)
                        <option value="{{ $itemtotal->nomCategorie }}">
                            {{ $itemtotal->nomCategorie }}
                        </option>
                    @endforeach
                    {{ $i+=1}}

                </optgroup>
            @endforeach
        </select>
    </div>
    <button type="submit" class="btn btn-primary float-right">Submit</button>
    <a href="{{route('depensecommuns.index')}}" class="btn btn-primary">annuler</a>
</form>
@endsection
