@extends('master')
@section('content')
    <div class="card">
        <h4 class="text-center">Depense</h4>
        <div class="card-body">
            <table class="table">
                <tbody>
                    <tr>
                        <td scope="row"><strong>description:   </strong> {{ $depensecommun->description }}</td>

                    </tr>
                    <tr>
                        <td scope="row"><strong>montant:   </strong> {{ $depensecommun->montantDepense }}</td>
                    </tr>
                    <tr scope="row">
                        @foreach ($categorie as $catego)
                            <td><strong>categorie:  </strong> {{ $catego->nomCategorie }}</td>

                        @endforeach
                    </tr>
                    <tr>
                        <td scope="row"><strong>Sous categorie: </strong> {{ $datafin->nomCategorie }}</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <a class="btn btn-primary float-right mt-5" href="{{route('depensecommuns.index')}}">retour</a>

@endsection
