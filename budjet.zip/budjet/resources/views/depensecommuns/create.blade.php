@extends('master')
@section('content')
    @if (Session::get('echec'))
        <div class="col-8 offset-2 col-lg-6 offset-lg-3 col-md-10 offset-md-1 mt-5">
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    <span class="sr-only">Close</span>
                </button>
                {{ Session::get('echec') }}
            </div>
        </div>
    @endif
    <form action={{ route('depensecommuns.store') }} method="post">
        @csrf
        @method('POST')
        <div class="form-group">
            <label for="">Montant</label>
            <input type="number" required value="{{ old('montant') }}" step="0.01" name="montant" id="" class="form-control"
                placeholder="" aria-describedby="helpId">
        </div>
        <div class="form-group">
            <label for="">Description dépense</label>
            <input type="text" required class="form-control" name="description" id="" aria-describedby="helpId"
                placeholder="">
        </div>
        <div class="form-group">
            <label for="">Categorie de la dépense</label>
            <select class="form-control" name="theId" id="">
                @foreach ($datadepense as $myitem)
                    <optgroup label="{{ $myitem->nomCategorie }}">
                        @foreach ($total[$i] as $itemtotal)
                            <option value="{{ $itemtotal->nomCategorie }}">
                                {{ $itemtotal->nomCategorie }}
                            </option>
                        @endforeach
                        {{ $i += 1 }}

                    </optgroup>
                @endforeach
            </select>
        </div>
        <button type="submit" class="btn btn-primary float-right">Submit</button>
        <a href="{{ route('depensecommuns.index') }}" class="btn btn-primary">annuler</a>
    </form>
    <a href="{{ route('categoriedepenses.create') }}" class="btn btn-primary mt-5">ajouer un sous categorie</a>
@endsection('content')
