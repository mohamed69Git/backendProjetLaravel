@extends('master')
@section('content')
    <div class="card">
        <h4 class="text-center">Revenu</h4>
        <div class="card-body">
            <table class="table table-striped table-inverse table-responsive">
                <tbody>
                    <tr>
                        <td scope="row"><strong>Revenu: </strong> {{ $revenu->montantRevenu }}</td>

                    </tr>
                    <tr>
                        @foreach ($categorie as $categorie)

                        <td scope="row"><strong>categorie: </strong> {{ $categorie->nomcategorie }}</td>
                        @endforeach
                    </tr>
                    <tr scope="row">
                        <td><strong>date de creation: </strong> {{ $revenu->created_at }}</td>

                    </tr>

                </tbody>
            </table>
        </div>
    </div>
    <a class="btn btn-primary float-right mt-5" href="{{ route('revenus.index') }}">retour</a>
    <a class="btn btn-primary float-right mt-5" href="{{ route('depensecommuns.index') }}">voir les depenses</a>

@endsection
