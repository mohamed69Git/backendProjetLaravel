@extends('master')
@section('content')
    <table class="table table-striped table-inverse table-responsive">
        <thead class="thead-inverse">
            <tr>
                <th>revenu</th>
                <th>categorie</th>
                <th>Date de creation</th>
                <td></td>
            </tr>
        </thead>
        <tbody>
            @foreach ($revenus as $revenu)
                <tr>
                    <td scope="row">{{ $revenu->montantRevenu }}</td>
                    <td>{{ $revenu->nomcategorie }}</td>
                    <td>{{ $revenu->datecrea }}</td>
                    <td>
                        <a title="afficher" href="{{ route('revenus.show', $revenu->mainId) }}" class="btn btn-primary"
                            role="button"><i class="fa fa-eye" aria-hidden="true"></i></a>
                        <a title="modifier" href="{{ route('revenus.edit', $revenu->mainId) }}" role="button"
                            class="ml-3 btn btn-primary"><i class="fas fa-pen"></i></a>
                        <form action="{{ route('revenus.destroy', $revenu->mainId) }}" method="post">
                            @csrf
                            @method('DELETE')
                            <button title="supprimer" class="btn btn-primary" type="submit"><i class="fa fa-trash"
                                    aria-hidden="true"></i></button>
                        </form>
                    </td>
                </tr>

            @endforeach
        </tbody>
    </table>
@endsection
