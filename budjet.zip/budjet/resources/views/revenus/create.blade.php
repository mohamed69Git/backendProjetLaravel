@extends('master')
@section('content')

<form action="{{route('revenus.store')}}" method="post">
    @csrf
    @method('POST')
    <div class="form-group">
      <label for="">montant de la revenu</label>
      <input type="number" required step="0.01" name="montantrevenu" id="" class="form-control" placeholder="" aria-describedby="helpId">
    </div>

    <div class="form-group">
      <label for="">Categorie </label>
      <select class="form-control" name="caterevenu" id="">
        @foreach ($data as $categ)
        <option value="{{$categ->id}}">{{$categ->nomcategorie}}</option>
        @endforeach
      </select>
    </div>
    <button type="submit" class="btn btn-primary float-right">Submit</button>
    <a href="{{route('depensecommuns.index')}}" class="btn btn-primary">annuler</a>
</form>
<a href="{{route('categorierevenus.create')}}" class="btn btn-primary mt-5">ajouter un autre categorie de revenu</a>
@endsection
