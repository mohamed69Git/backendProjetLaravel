@extends('master')
@section('content')
<form action="{{route('revenus.update', $revenu)}}" method="post">
    @csrf
    @method('PUT')
    <div class="form-group">
      <label for="">montant de la revenu</label>
      <input type="number" required step="0.01" value="{{$revenu->montantRevenu}}"name="montantrevenu" id="" class="form-control" placeholder="" aria-describedby="helpId">
    </div>

    <div class="form-group">
      <label for="">Categorie </label>
      <select class="form-control" name="caterevenu" id="">
        @foreach ($data as $categ)
        <option value="{{$categ->id}}">{{$categ->nomcategorie}}</option>
        @endforeach
      </select>
    </div>
    <button type="submit" class="btn btn-primary float-right">Submit</button>
    <a href="{{route('depensecommuns.index')}}" class="btn btn-primary">annuler</a>
</form>
@endsection
