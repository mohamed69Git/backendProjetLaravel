@extends('master')
@section('content')
<form action="{{route('categoriedepenses.store')}}" method="post">
    @csrf
    @method('POST')
    <div class="form-group">
      <label for="">nom de la sous categorie</label>
      <input type="text" required name="sousCat" id="" class="form-control" placeholder="" aria-describedby="helpId">
    </div>

    <div class="form-group">
      <label for="">Categorie </label>
      <select class="form-control" name="categParent" id="">
        <option value=1>Dépense Fixe</option>
        <option value=2>Dépense Fixe Frequence Variable</option>
        <option value=3>Dépense Spontanées</option>
      </select>
    </div>
    <button type="submit" class="btn btn-primary float-right">Submit</button>
</form>
@endsection
